function isEmail(e) {
    return er = /^[a-zA-Z0-9][a-zA-Z0-9\._-]+@([a-zA-Z0-9\._-]+\.)[a-zA-Z-0-9]{2}/, !!er.exec(e)
}

function checkCartMail() {
    var e = getRealCookie("cartmail");
    if ("" != e) return e
}
var scrolltotop = {
    setting: {
        startline: 500,
        scrollto: 0,
        scrollduration: 1e3,
        fadeduration: [500, 100]
    },
    controlHTML: '<div class="top_button"></div>',
    controlattrs: {
        offsetx: 5,
        offsety: 15
    },
    anchorkeyword: "#top",
    state: {
        isvisible: !1,
        shouldvisible: !1
    },
    scrollup: function() {
        this.cssfixedsupport || this.$control.css({
            opacity: 0
        });
        var e = isNaN(this.setting.scrollto) ? this.setting.scrollto : parseInt(this.setting.scrollto);
        e = "string" == typeof e && 1 == jQuery("#" + e).length ? jQuery("#" + e).offset().top : 0, this.$body.animate({
            scrollTop: e
        }, this.setting.scrollduration)
    },
    keepfixed: function() {
        var e = jQuery(window),
            t = e.scrollLeft() + e.width() - this.$control.width() - this.controlattrs.offsetx,
            o = e.scrollTop() + e.height() - this.$control.height() - this.controlattrs.offsety;
        this.$control.css({
            left: t + "px",
            top: o + "px"
        })
    },
    togglecontrol: function() {
        var e = jQuery(window).scrollTop();
        this.cssfixedsupport || this.keepfixed(), this.state.shouldvisible = e >= this.setting.startline, this.state.shouldvisible && !this.state.isvisible ? (this.$control.stop().animate({
            opacity: 1
        }, this.setting.fadeduration[0]), this.state.isvisible = !0) : 0 == this.state.shouldvisible && this.state.isvisible && (this.$control.stop().animate({
            opacity: 0
        }, this.setting.fadeduration[1]), this.state.isvisible = !1)
    },
    init: function() {
        jQuery(document).ready(function(e) {
            var t = scrolltotop,
                o = document.all;
            t.cssfixedsupport = !o || o && "CSS1Compat" == document.compatMode && window.XMLHttpRequest, t.$body = e(window.opera ? "CSS1Compat" == document.compatMode ? "html" : "body" : "html,body"), t.$control = e('<div id="topcontrol">' + t.controlHTML + "</div>").css({
                position: t.cssfixedsupport ? "fixed" : "absolute",
                bottom: t.controlattrs.offsety,
                right: t.controlattrs.offsetx,
                opacity: 0,
                cursor: "pointer"
            }).attr({
                title: "Ir para o Topo"
            }).click(function() {
                return t.scrollup(), !1
            }).appendTo("body"), document.all && !window.XMLHttpRequest && "" != t.$control.text() && t.$control.css({
                width: t.$control.width()
            }), t.togglecontrol(), e('a[href="' + t.anchorkeyword + '"]').click(function() {
                return t.scrollup(), !1
            }), e(window).bind("scroll resize", function(e) {
                t.togglecontrol()
            })
        })
    }
};
scrolltotop.init(), $.fn.extend({
    mask_brazilian_phone: function() {
        $(this[0]).focusout(function() {
            var e;
            (e = $(this)).unmask(), e.val().replace(/\D/g, "").length > 10 ? e.mask("(99) 99999-999?9") : e.mask("(99) 9999-9999?9")
        }).trigger("focusout")
    }
}), $(window).resize(function() {
    $(".modal-content").length > 0 && ($(".modal-dialog").animate({
        opacity: "1"
    }), popupRes($("#popup .modal-content")), popupRes($("#exit_popup .modal-content")))
}), $(window).load(function() {
    $("#blog .blog-item").length > 0 && ($(".blog-item .title").equalHeights(), $(".blog-item .resume").equalHeights())
}), $(document).ready(function() {
    $(".formAddCart").on("submit", function(e) {
        e.preventDefault();
        var t = $(this).serialize();
        return $.post(site_url.base + "/cart/add_to_cart", t, function(e) {
            var t = "R$ " + e.total.toFixed(2).replace(".", ",");
            $("#view_cartTotalItens").text(e.total_items), $("#view_cartTotalValue").text(t), $("#ProdModal .mod_prodaction .prodprice").html(t), $("#ProdModal").modal()
        }, "json"), !1
    }), setTimeout(function() {
        $(".modal-dialog").length > 0 && ($(".modal-dialog").animate({
            opacity: "1"
        }), popupRes($("#popup  .modal-content")), popupRes($("#exit_popup  .modal-content")))
    }, 200), setTimeout(function() {
        $("#flash .alert").animate({
            top: "5px",
            opacity: 1
        }, 500)
    }, 200), $(".close-alert").on("click", function() {
        $(this).closest(".alert").slideUp()
    }), $(".product-list-item").length > 0 && ($(".product-list-item .prod-info").equalHeights(), $(".product-list-item .prod-info h3").equalHeights(), $(".product-list-item .prod-info .price").equalHeights(), $(".product-list-item .prod-info .onsight-price").equalHeights(), $(".product-list-item .prod-image").equalHeights(), $(".product-list-item .prod-wrapper").equalHeights()), $(".prod-wrapper").mouseover(function() {
        $(this).parent().find(".prod-action").css("display", "block")
    }), $(".prod-wrapper").mouseout(function() {
        $(this).parent().find(".prod-action").css("display", "none")
    }), $(".prod-image").mouseover(function() {
        $(this).parent().find(".prod-hover-image").css("opacity", "1")
    }), $(".prod-image").mouseout(function() {
        $(this).parent().find(".prod-hover-image").css("opacity", "0")
    }), tabs_hash(), $(window).on("hashchange", tabs_hash), $(".imgLiquidFill").imgLiquid({
        fill: !1,
        horizontalAlign: "center",
        verticalAlign: "center"
    }), search_current_selection = 0, search_current_url = "", $("#search-engine").focus(function() {
        $("#search-results-in a").size() > 1 && search_show()
    }), $("#top-search input").on("keyup", function(e) {
        var t = e.keyCode;
        if (38 == t || 40 == t || 13 == t) {
            switch (0 == $("#search-results a.up").size() && (search_current_selection = -1), e.keyCode) {
                case 38:
                    -1 != search_current_selection && 0 != search_current_selection && search_current_selection--;
                    break;
                case 40:
                    search_current_selection != $("#search-results a").size() - 1 && search_current_selection++;
                    break;
                case 13:
                    "" == search_current_url && $("#form-search").submit(), "" != search_current_url && (document.location = search_current_url)
            }
            search_set_selected(search_current_selection)
        } else t >= 16 && t <= 20 || t >= 33 && t <= 37 || 39 == t || 45 == t || t >= 112 && t <= 145 || run_search_query()
    }), $("#top-search button").on("click", function() {
        $("#form-search").submit()
    })
}), popupRes = function(e) {
    var t = $(window).height(),
        o = e.outerHeight();
    e.animate({
        top: (t - o) / 2 + "px"
    })
}, getCookie = function(e) {
    var t = document.cookie,
        o = t.indexOf(" cookie=" + e);
    if (-1 == o && (o = t.indexOf("cookie=" + e)), -1 == o) t = null;
    else {
        o = t.indexOf("=", o) + 1;
        var s = t.indexOf(";", o); - 1 == s && (s = t.length), t = unescape(t.substring(o, s))
    }
    return t
}, del_cookie = function(e) {
    document.cookie = "cookie=" + e + "; expires=Thu, 01 Jan 1970 00:00:01 GMT;"
}, del_real_cookie = function(e, t) {
    document.cookie = e + "=" + t + "; expires=Thu, 01 Jan 1970 00:00:01 GMT;"
}, search_show = function() {
    $("#search-results").show()
}, search_close = function() {
    $("body").click(function(e) {
        var t = $(e.target);
        t.is("#search-results") || t.is("#top-search input") || ($("#search-results").hide(), $("#search-loader").hide())
    })
}, search_mouse_navigation = function() {
    $("#search-results a").hover(function() {
        "" != $(this).attr("id") && (search_current_selection = $(this).attr("id").substr(14), search_set_selected(search_current_selection))
    }, function() {
        $("#search-results a").removeClass("up"), search_current_url = ""
    })
}, search_set_selected = function(e) {
    $("#search-results a").removeClass("up"), $("#search-results a").eq(e).addClass("up"), search_current_url = $("#search-results a").eq(e).attr("href")
}, run_search_query = function() {
    $("#search-loader").show(), $.post(site_url.search_ajax, {
        name: $("#search-engine").val(),
        limit: 10
    }, function(e) {
        $("#search-results-in").html("");
        var t = "Nenhum produto foi encontrado.",
            o = 0;
        $.each(e, function(e, s) {
            if ("count" == e) t = 50 == s ? "Foram encontrados mais de " + s + " produtos." : "Foram encontrados " + s + " produtos.";
            else if ($("#search-results").show(), 0 == $(".search-result-" + e).length) {
                var i = "",
                    r = "";
                $.each(s.categories, function() {
                    r = this.name
                }), "0.00" == s.saleprice ? (product_price = s.price.replace(".", ","), i = '<span class="price">R$ ' + product_price + "</span>") : (product_saleprice = s.saleprice.replace(".", ","), product_price = s.price.replace(".", ","), i = '<span class="price"><span class="saleprice">R$ ' + product_price + "</span> R$ " + product_saleprice + "</span>"), $("#search-results-in").append('<a href="' + site_url.base + s.slug + '" id="search-result-' + o + '" class="search-result-' + e + '"><div class="line"><div class="image text-center">' + s.image + '</div><div class="desc"><span class="name">' + s.name + '</span><span class="category">' + r + "</span> " + i + '</div><div class="clearfix"></div></div></a>'), o++
            }
        }), $("#search-results-in").append('<div class="last text-center"><a href="#" onclick="$(\'#form-search\').submit();"><strong>Listar resultados</strong><br />' + t + "</a></div>"), $("#search-loader").hide(), search_show(), search_mouse_navigation(), search_close()
    }, "json")
}, tabs_hash = function() {
    if (window.location.hash) {
        var e = window.location.hash;
        $('#mytabs a[href="' + e + '"]').tab("show")
    }
}, $(function() {
    $(".showmoretxt").click(function() {
        $(".bio").toggleClass("crop")
    })
}), $("#zoom").bind("touchstart", function() {
    $("#zoom").unbind("touchmove")
}), $("#zoom").bind("click", function() {
    var e = $("#gallery-canvas").data("elevateZoom");
    return $.fancybox(e.getGalleryList()), !1
});

function getRealCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
    }
    return "";
}